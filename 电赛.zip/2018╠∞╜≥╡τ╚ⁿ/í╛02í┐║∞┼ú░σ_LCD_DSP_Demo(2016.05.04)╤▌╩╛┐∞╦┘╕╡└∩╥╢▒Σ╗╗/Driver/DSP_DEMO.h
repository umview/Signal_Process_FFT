#ifndef __DSP_DEMO_H
#define __DSP_DEMO_H

#include <stm32f10x.h>
#include "WB_LCD.h"
#include "math.h"
#include "stm32_dsp.h"

#define PI2  6.28318530717959

#define NPT 64                      // NPT = No of FFT point
#define DISPLAY_RIGHT 310           // 224 for centered, 319 for right-aligned 
#define DISPLAY_LEFT 150            // 224 for centered, 319 for right-aligned 

#define Line0          0
#define Line1          24
#define Line2          48
#define Line3          72
#define Line4          96
#define Line5          120
#define Line6          144
#define Line7          168
#define Line8          192
#define Line9          216



extern uint16_t TableFFT[];
extern volatile uint32_t TimingDelay ;

void DSPDemoInit(void);
void DisplayTitle(void);
void MyDualSweep(uint32_t freqinc1,uint32_t freqinc2);
#endif
