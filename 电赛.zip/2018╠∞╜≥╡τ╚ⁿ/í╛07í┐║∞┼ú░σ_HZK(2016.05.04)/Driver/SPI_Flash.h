#ifndef __SPI_FLASH_H
#define __SPI_FLASH_H

#include "stm32f10x.h"
#include "ff.h"
#include "USART.h"
#include "Gpio.h"
#include "WB_LCD.h"

#define GPIO_CS                  GPIOA
#define RCC_APB2Periph_GPIO_CS   RCC_APB2Periph_GPIOA
#define GPIO_Pin_CS              GPIO_Pin_4 


#define SPI_FLASH_CS_LOW()       GPIO_ResetBits(GPIO_CS, GPIO_Pin_CS)
#define SPI_FLASH_CS_HIGH()      GPIO_SetBits(GPIO_CS, GPIO_Pin_CS)

#define SPI_FLASH_PageSize       0x210                  //ҳ��СΪ528byte

#define SPI_FLASH_PageNum        4096
#define DF_READ_BUFFER           1 
#define DF_WRITE_BUFFER          0

#define WRITE      0x82  //д������ָ��
#define READ       0xD3  //��ȡ����ָ��
#define RDSR       0xD7  //���Ĵ���״̬
#define RDID       0x9F  //Read identification 
#define PE         0x81  //ҳ����
#define BE1        0xC7  // Bulk Erase instruction 
#define BE2        0x94  // Bulk Erase instruction 
#define BE3        0x80  // Bulk Erase instruction 
#define BE4        0x9A  // Bulk Erase instruction 

//�����붨�� 
//�������������붨���У������Ƭ����SCK�ź�Ƶ�ʸ���33MHz��ѡ�������������룬һ��AVR��SCK�ﲻ��33MHzΪЩѡ��0xd1��0xd3 
// buffer 1 read 
#define BUFFER_1_READ 0xd1 //0xD4 
// buffer 2 read 
#define BUFFER_2_READ 0xd3 //0xD6 

// buffer 1 write 
#define BUFFER_1_WRITE 0x84 

// buffer 2 write 
#define BUFFER_2_WRITE 0x87 

// buffer 1 to main memory page program with built-in erase 
#define B1_TO_MM_PAGE_PROG_WITH_ERASE 0x83 

// buffer 2 to main memory page program with built-in erase 
#define B2_TO_MM_PAGE_PROG_WITH_ERASE 0x86 

// buffer 1 to main memory page program without built-in erase 
#define B1_TO_MM_PAGE_PROG_WITHOUT_ERASE 0x88 

// buffer 2 to main memory page program without built-in erase 
#define B2_TO_MM_PAGE_PROG_WITHOUT_ERASE 0x89 

// main memory page program through buffer 1 
#define MM_PAGE_PROG_THROUGH_B1 0x82 

// main memory page program through buffer 2 
#define MM_PAGE_PROG_THROUGH_B2 0x85 

// auto page rewrite through buffer 1 
#define AUTO_PAGE_REWRITE_THROUGH_B1 0x58 

// auto page rewrite through buffer 2 
#define AUTO_PAGE_REWRITE_THROUGH_B2 0x59 

// main memory page compare to buffer 1 
#define MM_PAGE_TO_B1_COMP 0x60 

// main memory page compare to buffer 2 
#define MM_PAGE_TO_B2_COMP 0x61 

// main memory page to buffer 1 transfer 
#define MM_PAGE_TO_B1_XFER 0x53 

// main memory page to buffer 2 transfer 
#define MM_PAGE_TO_B2_XFER 0x55 

// DataFlash status register for reading density, compare status, 
// and ready/busy status 
#define STATUS_REGISTER 0xD7 

// main memory page read 
#define MAIN_MEMORY_PAGE_READ 0x52 

// erase a 528 byte page 
#define PAGE_ERASE 0x81 

// erase 512 pages 
#define BLOCK_ERASE 0x50 

#define BUSY_Flag  0x80 //æ��־

#define Dummy_Byte 0xA5

#define  FLASH_WriteAddress     0x000000
#define  FLASH_ReadAddress      FLASH_WriteAddress
#define  FLASH_SectorToErase    FLASH_WriteAddress
#define  AT45DB161D_FLASH_ID    0x1F260000
#define  BufferSize             (countof(Tx_Buffer)-1)
#define  countof(a)             (sizeof(a) / sizeof(*(a)))

void SPI_FLASH_Init(void);
void SPI_FLASH_PageErase(u32 SectorAddr);
void SPI_FLASH_BulkErase(void);
void SPI_FLASH_PageWrite(u8* pBuffer, u32 WriteAddr, u16 NumByteToWrite);
void SPI_FLASH_BufferWrite(u8* pBuffer, u32 WriteAddr, u16 NumByteToWrite);
void SPI_FLASH_BufferRead(u8* pBuffer, u32 ReadAddr, u16 NumByteToRead);
u32  SPI_FLASH_ReadID(void);

u8   SPI_FLASH_ReadByte(void);
u8   SPI_FLASH_SendByte(u8 byte);
u16  SPI_FLASH_SendHalfWord(u16 HalfWord);
void SPI_FLASH_WaitForWriteEnd(void);
void SPI_FLASH_Test(void);
void FontInit(void);
void df_write(u8 *buf,u8 size);
void df_write_close(void);
void df_write_open(u32 addr);
#endif 
