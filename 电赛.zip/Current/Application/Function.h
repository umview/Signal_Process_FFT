#ifndef _FUN_
#define _FUN_
#include "Gpio.h"
#include "delay.h"
#include "USART.h"
#include "ADC.h"
#include "SDS.h"
#include "fsmc_sram.h"
#include "Timer.h"
#include "stm32_dsp.h"
#include "math.h"
#include "Config.h"
/*******************************************/
void GetPowerMag(void);
#endif
